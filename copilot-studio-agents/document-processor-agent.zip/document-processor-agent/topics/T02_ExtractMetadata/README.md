# Extract Metadata

A schema-driven extraction topic that emits JSON.
